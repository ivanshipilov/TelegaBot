<?php

namespace App\Conversations;

use App\messengerUser as database;
use BotMan\BotMan\Messages\Attachments\Image;
use BotMan\BotMan\Messages\Conversations\Conversation;

use BotMan\BotMan\Messages\Incoming\Answer;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Outgoing\OutgoingMessage;
use BotMan\BotMan\Messages\Outgoing\Question;


class mainConversation extends conversation
{
    public $response = [];

    public function run ()
    {
        $this->askPhoto();
    }

    private function askPhoto()
    {
        $this->askForImages('Загрузите фото', function ($images)
        {
            $userID = $this->bot->getUser()->getId();
            foreach ($images as $image) {

                $url = $image->getUrl(); // The direct url
                //$payload = $image->getPayload();
                //file_put_contents('logs1.txt', "Возвращает: ".var_export(file_get_contents($url),true).PHP_EOL , FILE_APPEND | LOCK_EX); //для дебага
                //file_put_contents("img_1234.jpg", file_get_contents($url));
                //$this->isMorePhoto();
                //file_put_contents('logs2.txt', "в payload лежит: ".$payload. PHP_EOL , FILE_APPEND | LOCK_EX); //для дебага
                //file_put_contents("img_new.jpg", file_get_contents($payload));
                file_put_contents('logs1.txt', "в урл лежит: ".$url. PHP_EOL , FILE_APPEND | LOCK_EX); //для дебага
                file_put_contents('logs2.txt', "в урл лежит: ".str_replace("image/png;base64","imagdde/png;bsase54",$url). PHP_EOL , FILE_APPEND | LOCK_EX); //для дебага

            }

        }, function (Answer $answer)
        {
            $this->say('Блин, это ж не фото...');
            $this->askPhoto();
        });
    }

}